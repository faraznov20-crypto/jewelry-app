GRAND JEWELERS PENTAGON CITY — READY PACK

1) Upload everything in this folder to your GitHub repo:
   - app.py
   - requirements.txt
   - assets/ (folder with images inside)

2) Deploy on Streamlit Cloud.
   ✅ No more 'Folder not found'
   ✅ Images show immediately (luxury placeholders)
   ✅ Later you can replace images with real product photos using same filenames.
